import json
import os
import platform
import subprocess
import time
from collections import defaultdict
from pathlib import Path

started = time.perf_counter()
reports = []
collected = []


def pytest_collection_finish(session):
    collected.extend(item.nodeid for item in session.items)


def pytest_runtest_logreport(report):
    reports.append({'nodeid': report.nodeid, 'phase': report.when,
                    'outcome': report.outcome, 'seconds': report.duration})


def pytest_sessionfinish(session, exitstatus):
    totals = defaultdict(float)
    modules = defaultdict(lambda: defaultdict(float))
    for report in reports:
        totals[report['phase']] += report['seconds']
        modules[report['nodeid'].split('::')[0]][report['phase']] += report['seconds']
    result = {'sha': subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(),
              'platform': platform.platform(), 'python': platform.python_version(),
              'pytest_wall_seconds': time.perf_counter()-started,
              'exitstatus': int(exitstatus), 'phases': dict(totals),
              'modules': dict(modules), 'collected': collected, 'reports': reports}
    Path(os.environ['TEST_RUNTIME_OUTPUT']).write_text(json.dumps(result, indent=2)+'\n')
