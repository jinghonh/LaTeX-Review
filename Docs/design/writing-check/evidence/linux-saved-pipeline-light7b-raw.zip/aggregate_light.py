"""Aggregate outer LIGHT spans only. No cProfile or object/frame inspection."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
import zipfile

ROOT=Path('/tmp/writing-check-pipeline-light7.dndwbI')
OUT=Path('/home/ubuntu/.dsh/state/superagent/work/writing-check-delivery-6277b05259b6/Docs/design/writing-check/evidence')
EXPECTED='de00f087600364452c93faee440e9ece9435fb19b99c1d3fd91799e6877d560b'


def metrics(rows):
    result={'count':len(rows)}
    for key in ('thread_cpu_seconds','wall_seconds','thread_gc_cpu_seconds','thread_gc_wall_seconds',
                'observer_metadata_thread_cpu_seconds','peak_rss_after_kib'):
        values=[row[key] for row in rows]
        result[key]={'minimum':min(values),'median':statistics.median(values),
                     'maximum':max(values),'sum_overlapping':sum(values)}
    return result


analysis={'diagnostic_only':True,'cprofile_enabled':False,'tracemalloc_enabled':False,
          'head':'d2fc739b819e5c4bd8079db992b7edbe4cbcf4e2',
          'app_pin':'466a3213230dc59fc6405871eeb3a84c47a2d5bd','source_aggregate_sha256':EXPECTED,
          'source_file_count':120,
          'observer_sha256':hashlib.sha256((ROOT/'sitecustomize.py').read_bytes()).hexdigest(),
          'limitations':['Actual inclusive pipeline, light outer spans only; elapsed NOT latency acceptance/p95.',
                         'Canonical predicate/helpers/JSON decoder/SourceLocation unmodified; receipt eligibility observed true.',
                         'Per-stage thread CPU/wall and nested GC deltas OVERLAP: do not sum nested stages.',
                         'Process generation deltas can include OTHER threads; thread GC is collection time on this thread.',
                         'GC stage is where collection began, NOT proof of allocation origin or causal slowdown.',
                         'Receipt-before is a read-only snapshot, not an instrumented branch counter; racing readers can prime between observations.',
                         'Extra one SHA per decode plus outer snapshots/callbacks/event serialization perturb execution; metadata CPU recorded separately.',
                         'Peak RSS is cumulative process ru_maxrss in KiB, not live allocation or tracemalloc.',
                         'Attempt1 incomplete artifact retained:1 authoritative save then RuntimeError/build failure and original180s SettleTimeout; likely external GC-dictionary iteration, not proven production cause.',
                         'Attempt2 changed ONLY external observer to constant-size per-thread GC totals and reuses immutable before-hash after; source/app/helpers unchanged.'],
          'kinds':{}}
gc_summary={'diagnostic_only':True,'source_aggregate_sha256':EXPECTED,
            'attribution':'Exclusive GC callback labels; includes startup/saves/cleanup. Per-save root-span deltas in analysis.',
            'kinds':{}}
for kind in ('comment','prose'):
    directory=ROOT/f'attempt2-{kind}'
    events=sorted((json.loads(line) for file in (directory/'events').glob('*.jsonl') for line in file.read_text().splitlines()),key=lambda row:row['at'])
    installed=[r for r in events if r['event']=='installed']
    assert len(installed)==3 and all(r['canonical_receipt_eligible'] and not r['cprofile_enabled'] and not r['tracemalloc_enabled'] and not r['predicate_or_helpers_replaced'] and not r['json_decoder_replaced'] for r in installed)
    assert not any(r['event']=='installation_error' for r in events)
    spans=[r for r in events if r['event']=='span']
    assert not any(r['error'] for r in spans)
    bench=json.loads((OUT/f'linux-saved-pipeline-light7b-{kind}.json').read_text())
    assert bench['complete'] and len(bench['samples'])==2 and all(s['authoritative_match'] for s in bench['samples'])
    assert bench['source_paths_changed_during_measurement']==[]
    assert bench['source_boundary_begin']['aggregate_sha256']==bench['source_boundary_end']['aggregate_sha256']==EXPECTED
    assert len(bench['source_boundary_begin']['files'])==len(bench['source_boundary_end']['files'])==120
    assert bench['cleanup']=={'owned_entry_exit_code':0,'owned_entry_exited':True,'owned_worker_exited':True,'isolated_endpoint_removed':True}
    if kind=='prose':assert all(s['visible_change_proof']['verified_visible_text_change'] and s['visible_change_proof']['published_text_units']==5000 for s in bench['samples'])
    roots={(row['pid'],row['span']):row for row in spans if row['depth']==0}
    data={'installed_pids':[r['pid'] for r in installed],'span_count':len(spans),
          'authoritative_saved_samples':2,'cleanup':bench['cleanup'],'source_paths_changed_during_measurement':[],
          'instrumented_elapsed_not_acceptance':[s['save_to_verified_current_seconds'] for s in bench['samples']],
          'observer_metadata_cpu_sum_seconds':sum(r['observer_metadata_thread_cpu_seconds'] for r in spans),
          'stages_including_startup':{},'builds':[],'coordinators':[],'notifiers':[],
          'receipt_observations':{},'status_identity_hits':dict(Counter(str(r['server_identity_hit']) for r in spans if r['stage']=='http.status_identity'))}
    for stage in sorted({r['stage'] for r in spans}):data['stages_including_startup'][stage]=metrics([r for r in spans if r['stage']==stage])
    for label,target in [('live.build','builds'),('coordinator._execute','coordinators'),('saved.notifier','notifiers')]:
        selected=sorted([r for r in spans if r['stage']==label],key=lambda r:r['at'])
        assert len(selected)==3
        for ordinal,row in enumerate(selected):
            nested=[r for r in spans if r['pid']==row['pid'] and r['root_span']==row['span']]
            record={**row,'phase':'normal_initial_or_baseline' if ordinal==0 else f'actual_saved_edit_{ordinal}',
                    'gc_cpu_fraction':row['thread_gc_cpu_seconds']/row['thread_cpu_seconds'] if row['thread_cpu_seconds'] else 0,
                    'nested_observer_metadata_cpu_sum_seconds':sum(r['observer_metadata_thread_cpu_seconds'] for r in nested),
                    'nested_stages':{stage:metrics([r for r in nested if r['stage']==stage]) for stage in sorted({r['stage'] for r in nested})}}
            data[target].append(record)
    decodes=[r for r in spans if r['stage']=='manifest.decode']
    assert all(r['canonical_eligible_before'] and r['canonical_eligible_after'] and r['receipt_present_after'] and r['decoded_units']==5000 and r['receipt_entries_after']<=r['receipt_bound'] for r in decodes)
    for row in decodes:
        root=roots[(row['pid'],row['root_span'])]
        category='producer' if row['parent_stage']=='manifest.serialized_meta' else ('notifier' if root['stage']=='saved.notifier' else ('status' if root['stage']=='http.status_identity' else 'other_load_including_export'))
        data['receipt_observations'].setdefault(category,[]).append(row)
    for category,rows in data['receipt_observations'].items():
        data['receipt_observations'][category]={'count':len(rows),'eligible_before_true':sum(r['canonical_eligible_before'] for r in rows),
                    'receipt_present_before_true':sum(r['receipt_present_before'] for r in rows),
                    'receipt_present_before_false':sum(not r['receipt_present_before'] for r in rows),
                    'receipt_present_after_true':sum(r['receipt_present_after'] for r in rows),
                    'maximum_entries':max(r['receipt_entries_after'] for r in rows),'bound':128,
                    'metrics':metrics(rows),'rows':rows}
    summaries=[r for r in events if r['event']=='gc_summary']
    assert len(summaries)==3
    gc_summary['kinds'][kind]=summaries
    analysis['kinds'][kind]=data
for suffix,data in [('analysis',analysis),('gc-summary',gc_summary)]:
    path=OUT/f'linux-saved-pipeline-light7b-{suffix}.json'
    assert not path.exists()
    path.write_text(json.dumps(data,indent=2)+'\n')
archive=OUT/'linux-saved-pipeline-light7b-raw.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as bundle:
    for file in ('sitecustomize.py','aggregate_light.py'):bundle.write(ROOT/file,file)
    for kind in ('comment','prose'):
        for file in sorted((ROOT/f'attempt2-{kind}'/'events').glob('*.jsonl')):bundle.write(file,f'{kind}/events/{file.name}')
print('archive_bytes',archive.stat().st_size,'observer_sha256',analysis['observer_sha256'])
for kind,data in analysis['kinds'].items():
    print(kind,'spans',data['span_count'],'metadataCPUtotal',data['observer_metadata_cpu_sum_seconds'],'statushits',data['status_identity_hits'])
    for category,rows in data['receipt_observations'].items():print('receipts',category,'count',rows['count'],'hitbefore',rows['receipt_present_before_true'],'missbefore',rows['receipt_present_before_false'],'maxbound',rows['maximum_entries'])
    for section in ('builds','coordinators','notifiers'):
        for row in data[section][1:]:
            print(section,row['phase'],'PID',row['pid'],'CPU',row['thread_cpu_seconds'],'wall',row['wall_seconds'],'GCCPU',row['thread_gc_cpu_seconds'],'GCfraction',row['gc_cpu_fraction'],'peakKiB',row['peak_rss_after_kib'])
            if section!='notifiers':
                for stage,stats in row['nested_stages'].items():
                    if stage!=row['stage']:print(' ',stage,'CPU',stats['thread_cpu_seconds']['sum_overlapping'],'GCCPU',stats['thread_gc_cpu_seconds']['sum_overlapping'])
