"""External LIGHT diagnostic. No cProfile/tracemalloc, predicate or JSON patches."""
import atexit
import functools
import gc
from hashlib import sha256
import itertools
import json
import os
from pathlib import Path
import resource
import sys
import threading
import time

ROOT = Path(os.environ['WRITING_CHECK_LIGHT_DIR'])
(ROOT / 'events').mkdir(exist_ok=True)
_SEQ = itertools.count()
_LOCAL = threading.local()
_WRITE_LOCK = threading.Lock()
_GC_STARTED = {}
_GC_TOTAL = {}


def emit(event, **fields):
    row = {'event': event, 'pid': os.getpid(), 'thread': threading.get_ident(),
           'actor': Path(sys.argv[0]).name, 'at': time.perf_counter(), **fields}
    with _WRITE_LOCK:
        with (ROOT / 'events' / f'{os.getpid()}.jsonl').open('a') as stream:
            stream.write(json.dumps(row) + '\n')


def gc_observed(phase, info):
    # GC runs with the GIL. Never take the file lock or emit/inspect objects here.
    tid = threading.get_ident()
    if phase == 'start':
        _GC_STARTED[tid] = (time.perf_counter(), time.thread_time(),
                            getattr(_LOCAL, 'stage', 'unattributed'), info['generation'])
    elif phase == 'stop':
        start = _GC_STARTED.pop(tid, None)
        if start is not None:
            wall, cpu, stage, generation = start
            key = (tid, stage, generation)
            row = _GC_TOTAL.setdefault(key, [0, 0.0, 0.0, 0, 0])
            row[0] += 1
            row[1] += time.perf_counter() - wall
            row[2] += time.thread_time() - cpu
            row[3] += info.get('collected', 0)
            row[4] += info.get('uncollectable', 0)


def gc_thread_totals(tid):
    rows = [row for (thread, stage, generation), row in tuple(_GC_TOTAL.items()) if thread == tid]
    return [sum(row[index] for row in rows) for index in range(5)]


def peak_rss_kib():
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return value / 1024 if sys.platform == 'darwin' else value


def observe(label, original, before=None, after=None):
    @functools.wraps(original)
    def wrapped(*args, **kwargs):
        parent = getattr(_LOCAL, 'stage', None)
        depth = getattr(_LOCAL, 'depth', 0)
        prior_root = getattr(_LOCAL, 'root', None)
        span = next(_SEQ)
        root = span if depth == 0 else prior_root
        _LOCAL.stage, _LOCAL.depth, _LOCAL.root = 'observer.metadata', depth + 1, root
        metadata_start = time.thread_time()
        extra = before(args, kwargs) if before else {}
        observer_cpu = time.thread_time() - metadata_start
        tid = threading.get_ident()
        gc_before = gc.get_stats()
        thread_gc_before = gc_thread_totals(tid)
        rss_before = peak_rss_kib()
        _LOCAL.stage = label
        wall, cpu = time.perf_counter(), time.thread_time()
        error, result = None, None
        try:
            result = original(*args, **kwargs)
            return result
        except BaseException as caught:
            error = type(caught).__name__
            raise
        finally:
            elapsed, cpu_elapsed = time.perf_counter() - wall, time.thread_time() - cpu
            rss_after = peak_rss_kib()
            gc_after = gc.get_stats()
            thread_gc_after = gc_thread_totals(tid)
            _LOCAL.stage = 'observer.metadata'
            metadata_start = time.thread_time()
            if after and error is None:
                extra.update(after(args, kwargs, result, extra))
            observer_cpu += time.thread_time() - metadata_start
            _LOCAL.stage, _LOCAL.depth, _LOCAL.root = parent, depth, prior_root
            process_gc_delta = [{key: end[key] - start[key] for key in ('collections', 'collected', 'uncollectable')}
                                for start, end in zip(gc_before, gc_after)]
            emit('span', stage=label, parent_stage=parent, span=span, root_span=root, depth=depth,
                 revision=getattr(_LOCAL, 'revision', None), wall_seconds=elapsed,
                 thread_cpu_seconds=cpu_elapsed, observer_metadata_thread_cpu_seconds=observer_cpu,
                 process_gc_generation_deltas=process_gc_delta,
                 thread_gc_collections=thread_gc_after[0]-thread_gc_before[0],
                 thread_gc_wall_seconds=thread_gc_after[1]-thread_gc_before[1],
                 thread_gc_cpu_seconds=thread_gc_after[2]-thread_gc_before[2],
                 thread_gc_collected=thread_gc_after[3]-thread_gc_before[3],
                 thread_gc_uncollectable=thread_gc_after[4]-thread_gc_before[4],
                 peak_rss_before_kib=rss_before, peak_rss_after_kib=rss_after,
                 error=error, **extra)
    return wrapped


try:
    # Harness bootstrap state/cache variables are private BEFORE app imports.
    from latex_review import live, structure, preview, translation, reading, annotations
    from latex_review.annotations import content
    from latex_review.checks import http, service, snapshot, engine

    def receipt_before(args, kwargs):
        raw = args[0]
        namespace = content._validation_receipt_namespace()
        eligible = type(raw) is bytes and content._validation_receipt_eligible(namespace)
        key = (namespace, sha256(raw).digest()) if type(raw) is bytes else None
        with content._VALIDATION_RECEIPT_LOCK:
            present = bool(eligible and key in content._VALIDATION_RECEIPTS)
            entries = len(content._VALIDATION_RECEIPTS)
        # Only booleans/counts are emitted, never bytes, digest, namespace or args.
        return {'canonical_eligible_before': eligible, 'receipt_present_before': present,
                'receipt_entries_before': entries, 'receipt_bound': content._VALIDATION_RECEIPT_LIMIT,
                'raw_byte_count': len(raw), 'universal_newlines': bool(kwargs.get('_universal_newlines', False))}

    def receipt_after(args, kwargs, result, extra):
        raw = args[0]
        namespace = content._validation_receipt_namespace()
        eligible = type(raw) is bytes and content._validation_receipt_eligible(namespace)
        key = (namespace, sha256(raw).digest()) if type(raw) is bytes else None
        with content._VALIDATION_RECEIPT_LOCK:
            present = bool(eligible and key in content._VALIDATION_RECEIPTS)
            entries = len(content._VALIDATION_RECEIPTS)
        return {'canonical_eligible_after': eligible, 'receipt_present_after': present,
                'receipt_entries_after': entries,
                'decoded_units': len(result.get('units', ())) if type(result) is dict else None}

    content.decode_validated_content = observe('manifest.decode', content.decode_validated_content,
                                               receipt_before, receipt_after)
    content.load_content = annotations.load_content = observe('manifest.load', content.load_content)
    content._content_meta_from_serialized = observe('manifest.serialized_meta', content._content_meta_from_serialized)
    content.build_content = annotations.build_content = observe('annotations.build', content.build_content)
    parse = observe('source.parse_project', structure.parse_project)
    structure.parse_project = snapshot.parse_project = live.parse_project = parse
    render = observe('preview.render', preview.render_preview)
    preview.render_preview = live.render_preview = render
    units = observe('translation.units', translation.build_current_units)
    translation.build_current_units = live.build_current_units = units
    reading.build_reading = observe('reading.build', reading.build_reading)
    engine.evaluate_current = service.evaluate_current = observe('engine.evaluate', engine.evaluate_current)
    capture = observe('snapshot.capture', snapshot.capture_snapshot)
    identity = observe('snapshot.identity', snapshot.capture_content_id)
    snapshot.capture_snapshot = service.capture_snapshot = capture
    snapshot.capture_content_id = service.capture_content_id = identity
    for name in ('_execute', '_fresh'):
        setattr(service.CheckCoordinator, name, observe('coordinator.' + name, getattr(service.CheckCoordinator, name)))
    live._check_saved_recipe = observe('saved.notifier', live._check_saved_recipe)

    def status_before(args, kwargs):
        return {'had_server_identity_before': getattr(args[0].server, '_checks_status_identity', None) is not None}
    original_status = http._status_content_identity
    @functools.wraps(original_status)
    def observed_status(handler):
        before = getattr(handler.server, '_checks_status_identity', None)
        result = original_status(handler)
        after = getattr(handler.server, '_checks_status_identity', None)
        _LOCAL.last_status_hit = before is not None and before is after
        return result
    http._status_content_identity = observe('http.status_identity', observed_status, status_before,
                                          lambda a,k,r,e: {'server_identity_hit': _LOCAL.last_status_hit})
    profiled_build = observe('live.build', live.build)
    @functools.wraps(live.build)
    def observed_build(*args, **kwargs):
        prior = getattr(_LOCAL, 'revision', None)
        _LOCAL.revision = kwargs.get('revision', args[2] if len(args) > 2 else 1)
        try:
            return profiled_build(*args, **kwargs)
        finally:
            _LOCAL.revision = prior
    live.build = observed_build

    # None of these observers replace the canonical predicate, its helpers,
    # JSON decoder or SourceLocation. Assert actual fast-path eligibility.
    eligible = content._validation_receipt_eligible(content._validation_receipt_namespace())
    if not eligible:
        raise RuntimeError('light observers disabled canonical receipt eligibility')
    gc.callbacks.append(gc_observed)
    def finish():
        if gc_observed in gc.callbacks:
            gc.callbacks.remove(gc_observed)
        rows = [{'thread': tid, 'stage': stage, 'generation': generation,
                 'collections': values[0], 'wall_seconds': values[1], 'thread_cpu_seconds': values[2],
                 'collected': values[3], 'uncollectable': values[4]}
                for (tid, stage, generation), values in _GC_TOTAL.items()]
        emit('gc_summary', rows=rows, final_peak_rss_kib=peak_rss_kib())
    atexit.register(finish)
    emit('installed', canonical_receipt_eligible=eligible, cprofile_enabled=False, tracemalloc_enabled=False,
         predicate_or_helpers_replaced=False, json_decoder_replaced=False, peak_rss_kib=peak_rss_kib())
except BaseException as error:
    emit('installation_error', exception_class=type(error).__name__)
    os._exit(70)
