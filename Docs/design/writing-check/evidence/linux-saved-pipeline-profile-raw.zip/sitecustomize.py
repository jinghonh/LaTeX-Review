"""Private observational instrumentation; never imported by ordinary app runs."""
import cProfile
import functools
import itertools
import json
import os
from pathlib import Path
import sys
import threading
import time
import traceback

ROOT = Path(os.environ['WRITING_CHECK_DIAG_DIR'])
(ROOT / 'events').mkdir(exist_ok=True)
(ROOT / 'profiles').mkdir(exist_ok=True)
_SEQ = itertools.count()
_LOCAL = threading.local()
_LOCK = threading.Lock()


def emit(event, **fields):
    row = {'event': event, 'pid': os.getpid(), 'thread': threading.get_ident(),
           'actor': Path(sys.argv[0]).name, 'at': time.perf_counter(), **fields}
    with _LOCK:
        with (ROOT / 'events' / f'{os.getpid()}.jsonl').open('a') as stream:
            stream.write(json.dumps(row) + '\n')


def observe(label, original, metadata=None):
    @functools.wraps(original)
    def wrapped(*args, **kwargs):
        depth = getattr(_LOCAL, 'depth', 0)
        _LOCAL.depth = depth + 1
        profiler = cProfile.Profile() if depth == 0 else None
        extra = metadata(args, kwargs) if metadata else {}
        sequence = next(_SEQ)
        wall, cpu = time.perf_counter(), time.thread_time()
        error = None
        if profiler:
            profiler.enable()
        try:
            return original(*args, **kwargs)
        except BaseException as caught:
            error = type(caught).__name__
            raise
        finally:
            if profiler:
                profiler.disable()
            elapsed, cpu_elapsed = time.perf_counter() - wall, time.thread_time() - cpu
            _LOCAL.depth = depth
            profile = None
            if profiler:
                profile = f'{os.getpid()}-{sequence}-{label.replace(".", "_")}.prof'
                profiler.dump_stats(str(ROOT / 'profiles' / profile))
            emit('call', stage=label, depth=depth, wall_seconds=elapsed,
                 thread_cpu_seconds=cpu_elapsed, profile=profile, error=error,
                 revision=getattr(_LOCAL, 'revision', None), **extra)
    return wrapped


try:
    # All state/cache environment variables are private BEFORE these imports.
    from latex_review import live, sources, text_diff
    from latex_review.annotations import content
    from latex_review.checks import http, service, snapshot

    extract = content._extract_html_units
    @functools.wraps(extract)
    def observed_extract(*args, **kwargs):
        _LOCAL.extractions = getattr(_LOCAL, 'extractions', 0) + 1
        return extract(*args, **kwargs)
    content._extract_html_units = observed_extract

    html_units = content._html_units
    @functools.wraps(html_units)
    def observed_html_units(nodes, html):
        before = getattr(_LOCAL, 'extractions', 0)
        result = html_units(nodes, html)
        calls = getattr(_LOCAL, 'extractions', 0) - before
        emit('html_memo', revision=getattr(_LOCAL, 'revision', None),
             html_characters=len(html), nodes=len(nodes), units=len(result),
             extraction_calls=calls, actual_cache_hit=(calls == 0))
        return result
    content._html_units = observed_html_units

    profiled_build = observe('live.build', live.build,
                             lambda a, k: {'requested_revision': k.get('revision', a[2] if len(a) > 2 else 1)})
    @functools.wraps(live.build)
    def observed_build(*args, **kwargs):
        prior = getattr(_LOCAL, 'revision', None)
        _LOCAL.revision = kwargs.get('revision', args[2] if len(args) > 2 else 1)
        before = text_diff._memoized_sentences.cache_info()
        try:
            return profiled_build(*args, **kwargs)
        finally:
            after = text_diff._memoized_sentences.cache_info()
            emit('sentence_memo', revision=_LOCAL.revision,
                 hits=after.hits-before.hits, misses=after.misses-before.misses,
                 retained_entries=after.currsize, max_entries=after.maxsize)
            _LOCAL.revision = prior
    live.build = observed_build
    live._check_saved_recipe = observe('saved.notifier', live._check_saved_recipe)

    sources.ProjectSource.expand = observe('source.expand', sources.ProjectSource.expand)
    capture = observe('snapshot.capture', snapshot.capture_snapshot)
    identity = observe('snapshot.identity', snapshot.capture_content_id)
    snapshot.capture_snapshot = service.capture_snapshot = capture
    snapshot.capture_content_id = service.capture_content_id = identity
    snapshot._raw_files = observe('snapshot.raw_files', snapshot._raw_files)

    coordinator = service.CheckCoordinator
    for name in ('status', '_fresh', '_execute'):
        setattr(coordinator, name, observe('coordinator.' + name, getattr(coordinator, name)))
    http.worker_route = observe('http.worker_route', http.worker_route,
                                lambda a, k: {'method': a[0].command,
                                              'route': a[0].path.split('?')[0]})
    emit('installed', package_file=live.__file__)
except BaseException:
    emit('installation_error', detail=traceback.format_exc())
    os._exit(70)
