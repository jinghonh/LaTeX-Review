import collections
import hashlib
import json
from pathlib import Path
import pstats
import statistics
import subprocess
import zipfile

root = Path('/tmp/writing-check-pipeline-profile.EA2Ib9')
out = Path('/home/ubuntu/.dsh/state/superagent/work/writing-check-delivery-6277b05259b6/Docs/design/writing-check/evidence')
result = {'diagnostic_only': True,
          'description': 'Actual unchanged-package native watcher saves with external observational wrappers. cProfile perturbs timings: not saved-hot acceptance, not a comparison p95, not isolated causal speedup evidence. thread_cpu_seconds measures the executing thread; nested stage totals overlap. cProfile cumulative function timings are wall-clock, not CPU.',
          'git_head_observed': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          'instrumentation_sha256': hashlib.sha256((root/'sitecustomize.py').read_bytes()).hexdigest(),
          'instrumentation': 'sitecustomize.py inside accompanying archive; imported through private PYTHONPATH before app imports with isolated state/cache environment.',
          'kinds': {}}
for kind, directory in [('comment',root),('prose',root/'prose')]:
    events = sorted((json.loads(line) for path in (directory/'events').glob('*.jsonl') for line in path.read_text().splitlines()), key=lambda e:e['at'])
    failures = [e for e in events if e['event']=='installation_error' or e.get('error')]
    assert not failures, failures
    benchmark = json.loads((out/f'linux-saved-pipeline-profile-{kind}.json').read_text())
    assert benchmark['complete'] and len(benchmark['samples'])==2
    assert benchmark['source_paths_changed_during_measurement']==[]
    assert all(s['authoritative_match'] for s in benchmark['samples'])
    assert benchmark['cleanup']['owned_worker_exited'] and benchmark['cleanup']['owned_entry_exit_code']==0
    if kind=='prose':
        assert all(s['visible_change_proof']['verified_visible_text_change'] for s in benchmark['samples'])
    entry={'source_aggregate_sha256': benchmark['source_boundary_begin']['aggregate_sha256'],
           'source_paths_changed_during_measurement': [], 'cleanup': benchmark['cleanup'],
           'authoritative_samples':2,'instrumented_elapsed_not_acceptance_seconds':[s['save_to_verified_current_seconds'] for s in benchmark['samples']],
           'package_files_observed':sorted({e['package_file'] for e in events if e['event']=='installed'}),
           'builds':[],'stages_including_startup':{}}
    calls=[e for e in events if e['event']=='call']
    for stage in sorted({e['stage'] for e in calls}):
        selected=[e for e in calls if e['stage']==stage]
        def stats(field):
            values=[e[field] for e in selected]
            return {'count':len(values),'minimum':min(values),'median':statistics.median(values),'maximum':max(values),'sum_overlapping':sum(values)}
        entry['stages_including_startup'][stage]={'thread_cpu_seconds':stats('thread_cpu_seconds'),'wall_seconds':stats('wall_seconds')}
    for build in [e for e in calls if e['stage']=='live.build']:
        row=dict(build)
        row['phase']='initial throwaway preparation' if build['revision']==1 else f'actual saved edit {build["revision"]-1}'
        row['html_memo']=[e for e in events if e['event']=='html_memo' and e['pid']==build['pid'] and e['revision']==build['revision']]
        row['sentence_memo']=[e for e in events if e['event']=='sentence_memo' and e['pid']==build['pid'] and e['revision']==build['revision']]
        profile=pstats.Stats(str(directory/'profiles'/build['profile']))
        records=[]
        for (file,line,name),(primitive,count,own,cumulative,callers) in profile.stats.items():
            records.append({'file':file,'line':line,'function':name,'calls':count,'self_wall_seconds':own,'cumulative_wall_seconds':cumulative})
        row['top_cumulative_wall']=sorted(records,key=lambda r:r['cumulative_wall_seconds'],reverse=True)[:25]
        row['selected_profile_calls']={name:sum(r['calls'] for r in records if r['function']==name) for name in ('_extract_html_units','_html_units','_split_sentences','split_sentences','validate_content','enrich_content')}
        entry['builds'].append(row)
    result['kinds'][kind]=entry
result['same_source_aggregate_both_kinds']=len({v['source_aggregate_sha256'] for v in result['kinds'].values()})==1
path=out/'linux-saved-pipeline-profile-analysis.json'
path.write_text(json.dumps(result,indent=2)+'\n')
archive=out/'linux-saved-pipeline-profile-raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as zip:
    zip.write(root/'sitecustomize.py','sitecustomize.py')
    zip.write(root/'aggregate.py','aggregate.py')
    for kind,directory in [('comment',root),('prose',root/'prose')]:
        for subdir in ('events','profiles'):
            for source in sorted((directory/subdir).iterdir()):
                if source.is_file():zip.write(source,f'{kind}/{subdir}/{source.name}')
print('analysis',path,'raw_archive_bytes',archive.stat().st_size,'bootstrap_sha256',result['instrumentation_sha256'])
for kind, entry in result['kinds'].items():
    print(kind,'aggregate',entry['source_aggregate_sha256'])
    for b in entry['builds']:
        print(b['phase'],'pid',b['pid'],'CPU',b['thread_cpu_seconds'],'wall',b['wall_seconds'],'HTML',[(m['actual_cache_hit'],m['extraction_calls']) for m in b['html_memo']],'sentences',[(m['hits'],m['misses']) for m in b['sentence_memo']])
    for stage in ('coordinator._fresh','coordinator._execute','source.expand','snapshot.capture','snapshot.identity','saved.notifier'):
        print(stage,entry['stages_including_startup'][stage]['thread_cpu_seconds'])
