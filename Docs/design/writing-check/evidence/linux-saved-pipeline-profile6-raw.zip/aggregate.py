"""Aggregate external observational events, not latency acceptance evidence."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import pstats
import statistics
import zipfile

ROOT = Path('/tmp/writing-check-pipeline-profile6.hzeFt6')
OUT = Path('/home/ubuntu/.dsh/state/superagent/work/writing-check-delivery-6277b05259b6/Docs/design/writing-check/evidence')
EXPECTED = '42a8e701d215c4d937320986af55a1a987451083233d608b660a7775c1b92f31'
SELECTED = {'validate_content','load_content','content_meta','loads','read_text','read_bytes','map_range',
            'parse_project','build_content','enrich_content','render_preview','_render_node','build_current_units',
            '_protected_sentence','build_reading','evaluate_current','_capture','capture_snapshot','_extract_fragment',
            '_extract_html_units','_html_units','fragment_units'}

def summaries(rows):
    def stats(key):
        values=[row[key] for row in rows]
        return {'count':len(values),'minimum':min(values),'median':statistics.median(values),
                'maximum':max(values),'sum_overlapping':sum(values)}
    return {'thread_cpu_seconds':stats('thread_cpu_seconds'),'wall_seconds':stats('wall_seconds')}


def functions(directory, row):
    stats=pstats.Stats(str(directory/'profiles'/row['profile']))
    data=[{'file':file,'line':line,'function':name,'calls':count,
           'self_wall_seconds':own,'cumulative_wall_seconds':cum}
          for (file,line,name),(primitive,count,own,cum,callers) in stats.stats.items()]
    return {'top_cumulative_wall':sorted(data,key=lambda r:r['cumulative_wall_seconds'],reverse=True)[:40],
            'top_self_wall':sorted(data,key=lambda r:r['self_wall_seconds'],reverse=True)[:30],
            'selected_function_calls':[r for r in data if r['function'] in SELECTED]}


result={'diagnostic_only':True,'source_pin':'63108221c0f1f691fa98197fb74868b2eff8cfb6',
        'app_source_pin':'7744314e36634cdba55a306d9386b01107005336',
        'source_aggregate_sha256':EXPECTED,'source_file_count':120,
        'instrumentation_sha256':hashlib.sha256((ROOT/'sitecustomize.py').read_bytes()).hexdigest(),
        'limitations':['INSTRUMENTED actual watcher pipeline, not acceptance/p95 or a controlled speedup.',
                      'Stage thread CPU and wall measured separately; nested stage sums overlap.',
                      'cProfile per-function timings use wall clock, NOT per-function CPU.',
                      'Only stage-parent/span and numeric metadata logged: no arguments, credentials, nonce, document contents or environment values.',
                      'All state/cache environment variables private before sitecustomize imports; no app/helper source edits.'],
        'kinds':{}}
for kind,directory in [('comment',ROOT),('prose',ROOT/'prose')]:
    events=sorted((json.loads(line) for file in (directory/'events').glob('*.jsonl')
                   for line in file.read_text().splitlines()),key=lambda row:row['at'])
    assert not any(row['event']=='installation_error' for row in events)
    benchmark=json.loads((OUT/f'linux-saved-pipeline-profile6-{kind}.json').read_text())
    assert benchmark['complete'] and len(benchmark['samples'])==2
    assert benchmark['source_paths_changed_during_measurement']==[]
    assert benchmark['source_boundary_begin']['aggregate_sha256']==benchmark['source_boundary_end']['aggregate_sha256']==EXPECTED
    assert len(benchmark['source_boundary_begin']['files'])==120
    assert all(s['authoritative_match'] for s in benchmark['samples'])
    assert benchmark['cleanup']=={'owned_entry_exit_code':0,'owned_entry_exited':True,'owned_worker_exited':True,'isolated_endpoint_removed':True}
    if kind=='prose':
        assert all(s['visible_change_proof']['verified_visible_text_change'] and s['visible_change_proof']['published_text_units']==5000 for s in benchmark['samples'])
    calls=[row for row in events if row['event']=='call']
    entry={'cleanup':benchmark['cleanup'],'authoritative_samples':2,'source_paths_changed_during_measurement':[],
           'instrumented_elapsed_not_acceptance_seconds':[s['save_to_verified_current_seconds'] for s in benchmark['samples']],
           'installation_pids':[row['pid'] for row in events if row['event']=='installed'],
           'observed_errors':dict(Counter(row['error'] for row in calls if row['error'])),
           'stages_including_startup':{},'builds':[],'notifiers':[],'coordinators':[],
           'status_identity_hits':dict(Counter(str(row['actual_cache_hit']) for row in events if row['event']=='status_identity'))}
    for stage in sorted({row['stage'] for row in calls}):
        entry['stages_including_startup'][stage]=summaries([row for row in calls if row['stage']==stage])
    for build in [row for row in calls if row['stage']=='live.build']:
        nested=[row for row in calls if row['pid']==build['pid'] and row['root_span']==build['span']]
        data={**build,**functions(directory,build)}
        data['phase']='normal initial resident production build' if build['revision']==1 else f'actual saved edit {build["revision"]-1}'
        data['memo_events']=[row for row in events if row['event'] in ('fragment_memo','sentence_memo','html_memo') and row['pid']==build['pid'] and row['revision']==build['revision']]
        data['nested_stages']={stage:summaries([r for r in nested if r['stage']==stage])
                               for stage in sorted({r['stage'] for r in nested})}
        entry['builds'].append(data)
    for ordinal,notifier in enumerate(row for row in calls if row['stage']=='saved.notifier'):
        nested=[row for row in calls if row['pid']==notifier['pid'] and row['root_span']==notifier['span']]
        loads=[row for row in nested if row['stage']=='manifest.load']
        validates=[row for row in nested if row['stage']=='manifest.validate']
        data={**notifier,**functions(directory,notifier),'phase':'baseline' if ordinal==0 else f'actual saved edit {ordinal}',
              'manifest_load_count':len(loads),'manifest_validation_count':len(validates),
              'validated_unit_counts':[row['manifest_units'] for row in validates],
              'manifest_load_thread_cpu_seconds_total':sum(row['thread_cpu_seconds'] for row in loads),
              'manifest_validation_thread_cpu_seconds_total':sum(row['thread_cpu_seconds'] for row in validates),
              'nested_stages':{stage:summaries([r for r in nested if r['stage']==stage]) for stage in sorted({r['stage'] for r in nested})}}
        entry['notifiers'].append(data)
    for ordinal,coordinator in enumerate(row for row in calls if row['stage']=='coordinator._execute'):
        nested=[row for row in calls if row['pid']==coordinator['pid'] and row['root_span']==coordinator['span']]
        entry['coordinators'].append({**coordinator,**functions(directory,coordinator),
             'phase':'baseline' if ordinal==0 else f'actual saved edit {ordinal}',
             'nested_stages':{stage:summaries([r for r in nested if r['stage']==stage]) for stage in sorted({r['stage'] for r in nested})}})
    result['kinds'][kind]=entry
path=OUT/'linux-saved-pipeline-profile6-analysis.json'
path.write_text(json.dumps(result,indent=2)+'\n')
archive=OUT/'linux-saved-pipeline-profile6-raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as bundle:
    for name in ('sitecustomize.py','aggregate.py'):bundle.write(ROOT/name,name)
    for kind,directory in [('comment',ROOT),('prose',ROOT/'prose')]:
        for sub in ('events','profiles'):
            for source in sorted((directory/sub).iterdir()):
                if source.is_file():bundle.write(source,f'{kind}/{sub}/{source.name}')
print('analysis',path,'archive_bytes',archive.stat().st_size,'bootstrap_sha256',result['instrumentation_sha256'])
for kind,entry in result['kinds'].items():
    print(kind,'observed_errors',entry['observed_errors'],'status_identity_hits',entry['status_identity_hits'])
    for build in entry['builds']:
        print(build['phase'],'PID',build['pid'],'CPU',build['thread_cpu_seconds'],'wall',build['wall_seconds'],'memos',build['memo_events'])
    for row in entry['notifiers']:
        print('notifier',row['phase'],'CPU',row['thread_cpu_seconds'],'wall',row['wall_seconds'],
              'loadcount/valcount',row['manifest_load_count'],row['manifest_validation_count'],
              'loadCPUtotal',row['manifest_load_thread_cpu_seconds_total'],'valCPUtotal',row['manifest_validation_thread_cpu_seconds_total'])
    for row in entry['coordinators']:
        print('coordinator',row['phase'],'PID',row['pid'],'CPU',row['thread_cpu_seconds'],'wall',row['wall_seconds'])
