"""Private observational diagnostic only; no app/helper source modifications."""
import cProfile
import functools
import itertools
import json
import os
from pathlib import Path
import sys
import threading
import time
import traceback

ROOT = Path(os.environ['WRITING_CHECK_DIAG_DIR'])
(ROOT / 'events').mkdir(exist_ok=True)
(ROOT / 'profiles').mkdir(exist_ok=True)
_SEQ = itertools.count()
_LOCAL = threading.local()
_LOCK = threading.Lock()


def emit(event, **fields):
    row = {'event': event, 'pid': os.getpid(), 'thread': threading.get_ident(),
           'actor': Path(sys.argv[0]).name, 'at': time.perf_counter(), **fields}
    with _LOCK:
        with (ROOT / 'events' / f'{os.getpid()}.jsonl').open('a') as stream:
            stream.write(json.dumps(row) + '\n')


def observe(label, original, metadata=None):
    @functools.wraps(original)
    def wrapped(*args, **kwargs):
        depth = getattr(_LOCAL, 'depth', 0)
        parent = getattr(_LOCAL, 'stage', None)
        sequence = next(_SEQ)
        prior_root = getattr(_LOCAL, 'root_span', None)
        root_span = sequence if depth == 0 else prior_root
        _LOCAL.depth, _LOCAL.stage, _LOCAL.root_span = depth + 1, label, root_span
        profiler = cProfile.Profile() if depth == 0 else None
        extra = metadata(args, kwargs) if metadata else {}
        wall, cpu = time.perf_counter(), time.thread_time()
        error = None
        if profiler:
            profiler.enable()
        try:
            return original(*args, **kwargs)
        except BaseException as caught:
            error = type(caught).__name__
            raise
        finally:
            if profiler:
                profiler.disable()
            elapsed, cpu_elapsed = time.perf_counter() - wall, time.thread_time() - cpu
            _LOCAL.depth, _LOCAL.stage, _LOCAL.root_span = depth, parent, prior_root
            profile = None
            if profiler:
                profile = f'{os.getpid()}-{sequence}-{label.replace(".", "_")}.prof'
                profiler.dump_stats(str(ROOT / 'profiles' / profile))
            emit('call', stage=label, parent_stage=parent, span=sequence, root_span=root_span,
                 depth=depth, wall_seconds=elapsed, thread_cpu_seconds=cpu_elapsed,
                 profile=profile, error=error, revision=getattr(_LOCAL, 'revision', None), **extra)
    return wrapped


def unit_count(args, kwargs):
    return {'manifest_units': len(args[0].get('units', ())) if type(args[0]) is dict else None}


try:
    # All state/cache variables are private BEFORE these application imports.
    from latex_review import live, sources, text_diff, reading, annotations, local_client
    from latex_review.annotations import content, html_fragments
    from latex_review.checks import http, service, snapshot, engine, document

    extract = content._extract_html_units
    @functools.wraps(extract)
    def observed_extract(*args, **kwargs):
        _LOCAL.extractions = getattr(_LOCAL, 'extractions', 0) + 1
        return extract(*args, **kwargs)
    content._extract_html_units = observed_extract
    html_units = content._html_units
    @functools.wraps(html_units)
    def observed_html_units(nodes, html):
        before = getattr(_LOCAL, 'extractions', 0)
        result = html_units(nodes, html)
        calls = getattr(_LOCAL, 'extractions', 0) - before
        emit('html_memo', revision=getattr(_LOCAL, 'revision', None),
             html_characters=len(html), nodes=len(nodes), units=len(result),
             extraction_calls=calls, actual_cache_hit=(calls == 0))
        return result
    content._html_units = observed_html_units

    fragment_extract = html_fragments._extract_fragment
    @functools.wraps(fragment_extract)
    def observed_fragment_extract(*args, **kwargs):
        _LOCAL.fragment_extractions = getattr(_LOCAL, 'fragment_extractions', 0) + 1
        return fragment_extract(*args, **kwargs)
    html_fragments._extract_fragment = observed_fragment_extract
    fragment_units = html_fragments.fragment_units
    @functools.wraps(fragment_units)
    def observed_fragment_units(project, html, plan):
        before = getattr(_LOCAL, 'fragment_extractions', 0)
        result = fragment_units(project, html, plan)
        computed = getattr(_LOCAL, 'fragment_extractions', 0) - before
        roots = sum(bool(root.html) for root in plan.roots)
        emit('fragment_memo', revision=getattr(_LOCAL, 'revision', None),
             nonempty_roots=roots, fresh_fragment_extractions=computed,
             whole_parser_fallback=result is None,
             actual_fragment_hits=roots-computed if result is not None else None)
        return result
    html_fragments.fragment_units = observed_fragment_units

    profiled_build = observe('live.build', live.build,
                             lambda a, k: {'requested_revision': k.get('revision', a[2] if len(a) > 2 else 1)})
    @functools.wraps(live.build)
    def observed_build(*args, **kwargs):
        prior = getattr(_LOCAL, 'revision', None)
        _LOCAL.revision = kwargs.get('revision', args[2] if len(args) > 2 else 1)
        before = text_diff._memoized_sentences.cache_info()
        try:
            return profiled_build(*args, **kwargs)
        finally:
            after = text_diff._memoized_sentences.cache_info()
            emit('sentence_memo', revision=_LOCAL.revision,
                 hits=after.hits-before.hits, misses=after.misses-before.misses,
                 retained_entries=after.currsize, max_entries=after.maxsize)
            _LOCAL.revision = prior
    live.build = observed_build
    live._check_saved_recipe = observe('saved.notifier', live._check_saved_recipe)
    reading.build_reading = observe('reading.build', reading.build_reading)
    engine.evaluate_current = service.evaluate_current = observe('engine.evaluate', engine.evaluate_current)
    document.build_check_document = service.build_check_document = observe('document.build', document.build_check_document)

    content.validate_content = observe('manifest.validate', content.validate_content, unit_count)
    content.load_content = annotations.load_content = observe('manifest.load', content.load_content)
    content.content_meta = annotations.content_meta = observe('manifest.producer_meta', content.content_meta, unit_count)
    local_client.checks_request = observe('bridge.owner_request', local_client.checks_request,
                                         lambda a, k: {'operation': a[1].split('/')[0]})

    sources.ProjectSource.expand = observe('source.expand', sources.ProjectSource.expand)
    capture = observe('snapshot.capture', snapshot.capture_snapshot)
    identity = observe('snapshot.identity', snapshot.capture_content_id)
    snapshot.capture_snapshot = service.capture_snapshot = capture
    snapshot.capture_content_id = service.capture_content_id = identity
    snapshot._raw_files = observe('snapshot.raw_files', snapshot._raw_files)

    coordinator = service.CheckCoordinator
    for name in ('status', '_fresh', '_execute'):
        setattr(coordinator, name, observe('coordinator.' + name, getattr(coordinator, name)))
    status_identity = http._status_content_identity
    @functools.wraps(status_identity)
    def observed_status_identity(handler):
        before = getattr(handler.server, '_checks_status_identity', None)
        result = status_identity(handler)
        after = getattr(handler.server, '_checks_status_identity', None)
        emit('status_identity', actual_cache_hit=before is not None and before is after)
        return result
    http._status_content_identity = observe('http.status_identity', observed_status_identity)
    http.worker_route = observe('http.worker_route', http.worker_route,
                                lambda a, k: {'method': a[0].command,
                                              'route': a[0].path.split('?')[0]})
    emit('installed', package_file=live.__file__)
except BaseException:
    emit('installation_error', detail=traceback.format_exc())
    os._exit(70)
